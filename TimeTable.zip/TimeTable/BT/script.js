$(function(){
    
    $('.one').hover(function(){
        var x=document.getElementsByClassName('one');
        for(var i=0,len=x.length;i<len;i++){
            x[i].style.boxShadow="rgba(50, 50, 93, 0.70) 1px -1px 22px 4px inset";
            x[i].style.border="2px solid black";
            
        }
    },function(){
        var x=document.getElementsByClassName('one');
        for(var i=0,len=x.length;i<len;i++){
            x[i].style.boxShadow="none";
            x[i].style.border="2px solid #F0F8FF";
        }
    });
    $('.two').hover(function(){
        var x=document.getElementsByClassName('two');
        for(var i=0,len=x.length;i<len;i++){
            x[i].style.boxShadow="rgba(50, 50, 93, 0.70) 1px -1px 22px 4px inset";
            x[i].style.border="2px solid black";

        }
    },function(){
        var x=document.getElementsByClassName('two');
        for(var i=0,len=x.length;i<len;i++){
            x[i].style.boxShadow="none";
            x[i].style.border="2px solid #FAEBD7"
        }
    });
    $('.three').hover(function(){
        var x=document.getElementsByClassName('three');
        for(var i=0,len=x.length;i<len;i++){
            x[i].style.boxShadow="rgba(50, 50, 93, 0.70) 1px -1px 22px 4px inset";
            x[i].style.border="2px solid black";

        }
    },function(){
        var x=document.getElementsByClassName('three');
        for(var i=0,len=x.length;i<len;i++){
            x[i].style.boxShadow="none";
            x[i].style.border="2px solid #00FFFF"
            

        }
    });
    $('.four').hover(function(){
        var x=document.getElementsByClassName('four');
        for(var i=0,len=x.length;i<len;i++){
            x[i].style.boxShadow="rgba(50, 50, 93, 0.70) 1px -1px 22px 4px inset";
            x[i].style.border="2px solid black";

        }
    },function(){
        var x=document.getElementsByClassName('four');
        for(var i=0,len=x.length;i<len;i++){
            x[i].style.boxShadow="none";
            x[i].style.border="2px solid #98FB98"
        }
    });
    $('.five').hover(function(){
        var x=document.getElementsByClassName('five');
        for(var i=0,len=x.length;i<len;i++){
            x[i].style.boxShadow="rgba(50, 50, 93, 0.70) 1px -1px 22px 4px inset";
            x[i].style.border="2px solid black";

        }
    },function(){
        var x=document.getElementsByClassName('five');
        for(var i=0,len=x.length;i<len;i++){
            x[i].style.boxShadow="none";
            x[i].style.border="2px solid #FFFF00"
        }
    });
    $('.six').hover(function(){
        var x=document.getElementsByClassName('six');
        for(var i=0,len=x.length;i<len;i++){
            x[i].style.boxShadow="rgba(50, 50, 93, 0.70) 1px -1px 22px 4px inset";
            x[i].style.border="2px solid black";

        }
    },function(){
        var x=document.getElementsByClassName('six');
        for(var i=0,len=x.length;i<len;i++){
            x[i].style.boxShadow="none";
            x[i].style.border="2px solid #FF7F50"
        }

    });
    $('.seven').hover(function(){
        var x=document.getElementsByClassName('seven');
        for(var i=0,len=x.length;i<len;i++){
            x[i].style.boxShadow="rgba(50, 50, 93, 0.70) 1px -1px 22px 4px inset";
            x[i].style.border="2px solid black";

        }
    },function(){
        var x=document.getElementsByClassName('seven');
        for(var i=0,len=x.length;i<len;i++){
            x[i].style.boxShadow="none";
            x[i].style.border="2px solid #ffb3d9"
        }
    });
    $('.eight').hover(function(){
        var x=document.getElementsByClassName('eight');
        for(var i=0,len=x.length;i<len;i++){
            x[i].style.boxShadow="rgba(50, 50, 93, 0.70) 1px -1px 22px 4px inset";
            x[i].style.border="2px solid black";

        }
    },function(){
        var x=document.getElementsByClassName('eight');
        for(var i=0,len=x.length;i<len;i++){
            x[i].style.boxShadow="none";
            x[i].style.border="2px solid #9999ff"
        }
    });
    $('.nine').hover(function(){
        var x=document.getElementsByClassName('nine');
        for(var i=0,len=x.length;i<len;i++){
            x[i].style.boxShadow="rgba(50, 50, 93, 0.70) 1px -1px 22px 4px inset";
            x[i].style.border="2px solid black";

        }
    },function(){
        var x=document.getElementsByClassName('nine');
        for(var i=0,len=x.length;i<len;i++){
            x[i].style.boxShadow="none";
            x[i].style.border="2px solid #d2a679"
        }
    });
    $('.ten').hover(function(){
        var x=document.getElementsByClassName('ten');
        for(var i=0,len=x.length;i<len;i++){
            x[i].style.boxShadow="rgba(50, 50, 93, 0.70) 1px -1px 22px 4px inset";
            x[i].style.border="2px solid black";

        }
    },function(){
        var x=document.getElementsByClassName('ten');
        for(var i=0,len=x.length;i<len;i++){
            x[i].style.boxShadow="none";
            x[i].style.border="2px solid #b8b894"
        }
    });

});